import './lesson_11.scss';
import {calcTotalSalaries, findLargestSalary, toNames } from './scripts/salaries';

const salaries = [
  {
    name: 'John',
    salary: 2200
  },
  {
    name: 'Mike',
    salary: 250
  },
  {
    name: 'Alex',
    salary: 2560
  },
  {
    name: 'James',
    salary: 1200
  }
];

console.log(calcTotalSalaries(salaries));
console.log(findLargestSalary(salaries));
console.log(toNames(salaries));