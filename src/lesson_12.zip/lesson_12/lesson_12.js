import './lesson_12.scss';
import { LighterController } from './scripts/lighterController';

const control = new LighterController(document.querySelector('body'));